package com.server.demomvp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomvpApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemomvpApplication.class, args);
	}

}
